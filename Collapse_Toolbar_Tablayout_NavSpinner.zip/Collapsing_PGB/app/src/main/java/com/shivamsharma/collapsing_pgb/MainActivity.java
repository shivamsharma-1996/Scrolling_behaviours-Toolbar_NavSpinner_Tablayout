package com.shivamsharma.collapsing_pgb;

import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity  implements AdapterView.OnItemSelectedListener, ActionBar.OnNavigationListener{

    private ViewPager mViewPager;
    private ViewPagerAdapter mSectionsViewPagerAdapter;
    private TabLayout mTabLayout;

    private ArrayAdapter<String> acommTypeAdapter;
    private Spinner acommTypeSpinner;


    // action bar
    private ActionBar actionBar;


    // Navigation adapter
    private ArrayAdapter<String> nav_switch_adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        android.support.v7.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);                    // Hide the action bar title

        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);


        //navigation_spinner on toolbar sources - https://stackoverflow.com/questions/26739022/change-spinner-style-in-toolbar & AndroidInfo.com
        nav_switch_adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.accomAreas) );
        nav_switch_adapter.setDropDownViewResource(android.R.layout.select_dialog_singlechoice);
        actionBar.setListNavigationCallbacks(nav_switch_adapter, this);

        initViews();
    }

    private void initViews()
    {
        //Tabs
        mViewPager = (ViewPager) findViewById(R.id.main_tabPager);
        mSectionsViewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager() , this);
        mViewPager.setAdapter(mSectionsViewPagerAdapter);
        mTabLayout = (TabLayout) findViewById(R.id.main_tabs);
        mTabLayout.setupWithViewPager(mViewPager);

        //Spinners
        acommTypeSpinner = (Spinner) findViewById(R.id.main_accomTypes);


        //Adapters
        String[] acommTypes = getResources().getStringArray(R.array.accomTypes);
        acommTypeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, acommTypes);
        acommTypeAdapter.setDropDownViewResource(android.R.layout.select_dialog_singlechoice);
        acommTypeSpinner.setAdapter(acommTypeAdapter);

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
    {
        Spinner spinner = (Spinner) adapterView;

        switch (spinner.getId())
        {
            case R.id.main_accomTypes:
                Toast.makeText(this, adapterView.getItemAtPosition(position).toString(), Toast.LENGTH_LONG).show();
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public boolean onNavigationItemSelected(int itemPosition, long itemId)
    {
        // here nav_spinner click handling is place
        return false;
    }
}
